
// script.js
// Función para llamar a un número de teléfono
function llamar(numero) {
    window.location.href = "tel:" + numero;
}